/* GreenHope Community Foundation — Part 2: script.js
   Mobile menu, enquiry tabs, form validation, stat counters, footer year.
*/

document.addEventListener('DOMContentLoaded', function () {
    /* ---------- 1. Mobile navigation toggle ---------- */
    const menuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');

    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', function () {
            const isOpen = mainNav.classList.toggle('open');
            menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        // Close the menu when a nav link is clicked (mobile UX)
        mainNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                mainNav.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    /* ---------- 2. Enquiry page tabs ---------- */
    const tabs = document.querySelectorAll('.enquiry-tab');
    const forms = document.querySelectorAll('.enquiry-form');

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            const target = tab.getAttribute('data-tab');

            tabs.forEach(function (t) {
                t.classList.remove('active');
                t.setAttribute('aria-selected', 'false');
            });
            tab.classList.add('active');
            tab.setAttribute('aria-selected', 'true');

            forms.forEach(function (form) {
                const isTarget = form.id === target + '-form';
                form.classList.toggle('active', isTarget);
            });
        });
    });

    /* ---------- 3. Client-side form validation ---------- */
    document.querySelectorAll('form.validate-on-submit').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            let valid = true;

            form.querySelectorAll('[required]').forEach(function (field) {
                const errorSpan = field.closest('.form-group')
                    ? field.closest('.form-group').querySelector('.error-message')
                    : null;
                const value = field.value.trim();
                let message = '';

                if (!value) {
                    message = 'This field is required.';
                } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                    message = 'Please enter a valid email address.';
                } else if (field.type === 'tel' && !/^[0-9+\-\s()]{7,}$/.test(value)) {
                    message = 'Please enter a valid phone number.';
                }

                if (message) {
                    valid = false;
                    field.classList.add('invalid');
                    if (errorSpan) errorSpan.textContent = message;
                } else {
                    field.classList.remove('invalid');
                    if (errorSpan) errorSpan.textContent = '';
                }
            });

            if (valid) {
                const success = form.querySelector('.form-success');
                if (success) {
                    success.classList.add('visible');
                    success.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                form.reset();
            }
        });
    });

    /* ---------- 4. Newsletter form (demo handling) ---------- */
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function (event) {
            event.preventDefault();
            const email = newsletterForm.querySelector('input[type="email"]');
            if (email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
                alert('Thank you for subscribing to the GreenHope newsletter!');
                newsletterForm.reset();
            } else {
                alert('Please enter a valid email address.');
            }
        });
    }

    /* ---------- 5. Animated stat counters (home page) ---------- */
    const statNumbers = document.querySelectorAll('.stat-number');
    if (statNumbers.length) {
        const animateCounter = function (el) {
            const target = parseInt(el.getAttribute('data-target'), 10);
            const duration = 1500;
            const start = performance.now();

            const step = function (now) {
                const progress = Math.min((now - start) / duration, 1);
                el.textContent = Math.floor(progress * target).toLocaleString();
                if (progress < 1) requestAnimationFrame(step);
            };
            requestAnimationFrame(step);
        };

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        statNumbers.forEach(function (el) { observer.observe(el); });
    }

    /* ---------- 6. Dynamic footer year ---------- */
    const yearSpan = document.querySelector('.current-year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});
