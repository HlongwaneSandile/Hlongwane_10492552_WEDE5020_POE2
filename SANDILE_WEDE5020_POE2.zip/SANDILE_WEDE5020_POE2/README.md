# GreenHope Community Foundation Website

**Module:** WEDE5020 — Web Development  
**Part:** Part 2 of 2 — Designing the Visuals: CSS Styling and Responsive Design  
**Student:** Sandile  
**Year:** 2026

---

## 1. Project Overview

This repository contains the GreenHope Community Foundation website — a multi-page,
static website for a fictional South African non-profit organisation. The site
promotes the organisation's three core programs (Community Gardens, Youth Green
Skills Academy, and Environmental Education), recruits volunteers and sponsors
through enquiry forms, and provides contact details for three Gauteng locations.

**Live pages:**

| Page | File | Purpose |
|------|------|---------|
| Home | `index.html` | Hero banner, impact statistics, about preview, program cards, newsletter signup |
| About Us | `about.html` | Organisation history, mission/vision, timeline, team profiles |
| Our Programs | `services.html` | Detailed breakdown of the three core programs |
| Enquiry | `enquiry.html` | Volunteer and Sponsor/Partner enquiry forms with tabbed navigation |
| Contact | `contact.html` | Three location cards with embedded maps + general contact form |

---

## 2. Part 2 Changes Summary

Part 2 focused on **CSS styling and responsive design** for the website
originally structured in Part 1:

- **External stylesheet** — all styling moved into `css/style.css`, linked from
  every HTML page. No inline styles remain.
- **CSS reset** — a modern reset normalises margins, padding, box-sizing and
  media defaults across browsers.
- **Base styles** — CSS custom properties (design tokens) define the colour
  scheme, typography scale, spacing scale, shadows and transitions in one
  place (`:root`).
- **Typography** — Montserrat (headings) and Open Sans (body) loaded from
  Google Fonts; a modular type scale is applied via `rem` units.
- **Layout** — Flexbox (header, about preview, contact details, newsletter)
  and CSS Grid (stats, programs, team, forms, footer) create the desktop
  layout.
- **Visual styles** — buttons, cards, forms, timeline and footer styled with
  `color`, `background-color`, `border`, `border-radius` and `box-shadow`;
  interactive pseudo-classes (`:hover`, `:focus`, `:active`) provide feedback.
- **Responsive design** — three breakpoints (1024px tablet, 768px mobile,
  480px small mobile) switch multi-column layouts to single-column, convert
  the navigation to a hamburger menu, and adjust font sizes and spacing.
- **Relative units** — font sizes, spacing and widths use `rem`/`%` so the
  layout scales smoothly.
- **Responsive images** — all `<img>` elements use `max-width: 100%` and
  `height: auto`; images load lazily (`loading="lazy"`).
- **JavaScript** — `js/script.js` powers the mobile menu, enquiry tabs,
  client-side form validation, animated stat counters and the dynamic footer year.

---

## 3. File Structure

```
SANDILE_WEDE5020_POE2/
├── index.html          # Home page
├── about.html          # About Us page
├── services.html       # Our Programs page
├── enquiry.html        # Enquiry forms page
├── contact.html        # Contact page
├── css/
│   └── style.css       # External stylesheet (all pages)
├── js/
│   └── script.js       # Mobile menu, tabs, validation, counters
└── README.md           # This file
```

---

## 4. Responsive Breakpoints

| Breakpoint | Target | Key changes |
|------------|--------|-------------|
| `> 64rem` (1024px+) | Desktop | Full multi-column Grid/Flexbox layouts, horizontal nav |
| `≤ 64rem` | Tablet | 2-column grids, stacked contact layout, tighter spacing |
| `≤ 48rem` | Mobile | Single-column layouts, hamburger menu, full-width buttons |
| `≤ 30rem` | Small mobile | Full-width buttons and tabs, reduced type scale |

The layout was tested using browser developer tools (Chrome DevTools device
toolbar) at desktop (1440px), tablet (768px) and mobile (375px) sizes.

---

## 5. Changelog

### Part 2 — Designing the Visuals (current)

- **2026-09-18** — Created `css/style.css` with a CSS reset, design tokens
  (colours, type scale, spacing), base styles, header/navigation, hero,
  stats, programs, services, timeline, team, forms, newsletter and footer
  styles.
- **2026-09-18** — Implemented responsive design with media queries at
  64rem, 48rem and 30rem breakpoints; multi-column layouts collapse to a
  single column on mobile.
- **2026-09-18** — Replaced the desktop-only navigation with an accessible
  hamburger menu on mobile (with `aria-expanded` state management).
- **2026-09-18** — Added `js/script.js`: mobile menu toggle, enquiry tab
  switching, client-side form validation with inline error messages,
  animated impact-stat counters, newsletter demo handling, dynamic footer year.
- **2026-09-18** — Removed all inline styles from HTML (moved into the
  external stylesheet) and normalised page filenames to lowercase
  (`index.html`, `about.html`, `services.html`, `enquiry.html`, `contact.html`)
  for consistency and web-server compatibility.
- **2026-09-18** — Updated this README with Part 2 information, changelog
  and references.

### Part 1 — Feedback Edits (carried forward)

- **2026-09-18** — Fixed inconsistent page filename capitalisation
  (`Index.html`, `About.html`, `Services.html`, `Contact.html` → lowercase)
  and updated all internal links accordingly.
- **2026-09-18** — Removed inline `style` attributes (e.g. visually-hidden
  helpers) and replaced them with reusable `.visually-hidden` CSS class.
- **2026-09-18** — Added/kept semantic HTML5 landmarks (`header`, `nav`,
  `main`, `section`, `article`, `footer`) and ARIA labels from Part 1.

---

## 6. References

- MDN Web Docs — CSS: Cascading Style Sheets. Available at:
  https://developer.mozilla.org/en-US/docs/Web/CSS
- MDN Web Docs — Responsive images (`srcset`, `sizes`, `<picture>`).
  Available at: https://developer.mozilla.org/en-US/docs/Learn/HTML/Multimedia_and_embedding/Responsive_images
- MDN Web Docs — CSS Grid Layout. Available at:
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs — Flexbox. Available at:
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- Google Fonts — Montserrat & Open Sans. Available at:
  https://fonts.google.com/
- Unsplash — royalty-free photography used for page imagery. Available at:
  https://unsplash.com/
- The Independent Institute of Education (Pty) Ltd — WEDE5020 POE brief (2026).

---

## 7. How to Run

1. Clone or download this repository.
2. Open `index.html` in any modern browser, **or** serve the folder with a
   local server (e.g. `npx serve` or VS Code Live Server) so relative paths
   resolve correctly.
3. Resize the browser window (or use DevTools device emulation) to see the
   responsive breakpoints in action.
